package az.ingress.aaaaaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AaaaaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}

package az.ingress.aaaaaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AaaaaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AaaaaSpringApplication.class, args);
	}

}

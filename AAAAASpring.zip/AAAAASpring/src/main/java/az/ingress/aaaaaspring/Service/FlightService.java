package az.ingress.aaaaaspring.Service;

import az.ingress.aaaaaspring.Model.Response.FlightDetailsResponse;
import lombok.Data;
import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class FlightService {
    private final Map<String, FlightDetailsResponse> flightDetailsMap = new HashMap<>();


    public void addFlightDetails(Long id, String from, String to, LocalDateTime time, String planeModel, Integer passangerCount, String pilotName) {
        FlightDetailsResponse flight = new FlightDetailsResponse(from,to,time,planeModel,passangerCount,pilotName);
        flightDetailsMap.put(String.valueOf(id), flight);
    }


    public FlightDetailsResponse getFlightDetailsById(Long id) {
        return flightDetailsMap.get(id);
    }

    public static void main(String[] args) {
        FlightService service = new FlightService();


        service.addFlightDetails(1l,"Baku","Leipzig",LocalDateTime.now(),"aaa",54,"Vagif");
        service.addFlightDetails(2l,"Baku","Leipzig",LocalDateTime.now(),"aaa",45,"Vagif");
        service.addFlightDetails(3l,"Baku","Leipzig",LocalDateTime.now(),"aaa",87,"Vagif");
        service.addFlightDetails(4l,"Baku","Leipzig",LocalDateTime.now(),"aaa",3245,"Vagif");



        FlightDetailsResponse flight = service.getFlightDetailsById(1L);
        if (flight != null) {
            System.out.println("Tapılan reys: " + flight);
        } else {
            System.out.println("Bu id ilə reys tapılmadı.");
        }
    }
}
